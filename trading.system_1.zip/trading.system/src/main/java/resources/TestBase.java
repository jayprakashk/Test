package resources;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeSuite;
import com.fintech.currency.Constants;

public class TestBase {

	// public static Logger log =LogManager.getLogger(traderLogin.class.getName());
	// static Logger log = Logger.getLogger(TestBase.class.getName());
	public Logger log = Logger.getLogger("devpinoyLogger");
	public String log4jConfPath = "Log4j.properties";

	public static WebDriver driver = null;

	@BeforeSuite

	public WebDriver browserLaunch() throws Exception {
		PropertyConfigurator.configure(log4jConfPath);

		if (Constants.browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\src\\test\\resources\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			System.out.println("Chrome browser launched");
			log.debug("Chrome launched");
		} else if (Constants.browser.equals("firefox")) {

			System.setProperty("webdriver.firefox.marionette",
					System.getProperty("user.dir") + "\\src\\test\\resources\\Drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
			log.debug("Firefox launched");
		} else if (Constants.browser.equals("ie")) {

			System.setProperty("webdriver.edge.driver",
					System.getProperty("user.dir") + "\\src\\test\\resources\\Drivers\\MicrosoftWebDriver.exe");
			// create Edge instance
			driver = new EdgeDriver();
			log.debug("IE launched");
		} else {
			// If no browser passed throw exception
			throw new Exception("Browser is not correct");
		}

		driver.manage().window().maximize();
		System.out.println("Chrome browser maximized");
		log.debug("Chrome browser maximized");

		driver.get(Constants.url);
		System.out.println("URL get entered ");
		log.debug("URL get Entered");
		
		driver.manage().timeouts().implicitlyWait(Constants.implecitwait, TimeUnit.SECONDS);
	
		
		return driver;

		
		
		
		
	}
}
