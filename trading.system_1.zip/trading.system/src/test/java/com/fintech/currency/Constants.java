package com.fintech.currency;

public class Constants {
	
	public static final String browser ="chrome";
	public static final String pname ="O/N THB";
	public static final String productname ="INR";
	public static final String currencyname ="1W x 1M INR";
	public static final String currencqty ="1M x 24M INR";
	public static final String title ="XP Securities - Investments in Global Assets";
	public static final String ordertype ="FAS";
	
	//FOR TEST ENVIRONMENT 
	public static final String url ="http://wwwtest.vcmpartners.com/xpndfasia/Views/Home.html";
	public static final String traderid ="jayprakash.trader2@fintechglobal.center";
	public static final String traderpass ="Passw0rd@123";
	public static final String traderid1 ="jayprakash.trader1@fintechglobal.center";
	public static final String traderpass1 ="Passw0rd@123";
	public static final String brokerid ="jayprakash.broker@fintechglobal.center";
	public static final String brokerpass ="Passw0rd@123";
	public static final String productoutright ="IDR OUTRIGHT";
	public static final String pitsoutright ="2M IDR";
	public static final String productswitch ="INR";
	public static final String pitsswitch ="1M x 9M INR";
	public static final long implecitwait = 10;

}
