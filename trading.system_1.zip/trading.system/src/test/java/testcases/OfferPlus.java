package testcases;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import pages.BidPlusPage;
import pages.OfferPlusPage;
import resources.TestBase;

public class OfferPlus extends TestBase {

	@Test
	public void doBidPlus() throws Exception {

		checkCaretExpand();
		createOfferPlus();
		expandToCheckAllOffer();
	}

	private void expandToCheckAllOffer() {
		BidPlusPage bp = PageFactory.initElements(driver, BidPlusPage.class);
		bp.expand.click();
	}

	private void checkCaretExpand() {
		OfferPlusPage bp = PageFactory.initElements(driver, OfferPlusPage.class);
		try {
			WebDriverWait wait = new WebDriverWait(driver, 1);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(
					"//div[@id='productWrapper']/div[1]/div[1]/table/thead/tr/th[1]/div/div/a/span[@class='fa fa-caret-right']")));
			bp.caretright.click();
			System.out.println("Caret expand");
			log.debug("Caret expand");
		} catch (Exception e) {
			System.out.println("Caret Already expand");
			log.debug("Caret Already expand");
		}
	}

	private void createOfferPlus() throws InterruptedException {
		OfferPlusPage bp = PageFactory.initElements(driver, OfferPlusPage.class);
		
		Thread.sleep(3000);
		for (int i = 0; i < 6; i++) {
			bp.firstpitoffer.click();
			Thread.sleep(2000);
			bp.rateminus.click();
			Thread.sleep(2000);
			bp.offerplus.click();
			try {
				WebDriverWait wait = new WebDriverWait(driver, 2);
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert = driver.switchTo().alert();
				alert.accept();
				System.out.println("Alert accepted ");
				log.debug("Alert accepted ");
			} catch (Exception e) {
				System.out.println("No alert displayed");
				log.debug("No alert displayed");
			}
			System.out.println("Offer Plus palced ");
			log.debug("Offer Plus palced ");
			Thread.sleep(3000);
			checkBlotterAndStrike();
		}
	}

	private void checkBlotterAndStrike() throws InterruptedException {
		OfferPlusPage bp = PageFactory.initElements(driver, OfferPlusPage.class);
		Thread.sleep(2000);
		bp.OblotterProduct.click();

		String OBname = bp.OblotterProduct.getText();
		Thread.sleep(3000);
		String OBrate = bp.OblotterRate.getText();

		System.out.println("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		log.debug("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);

		bp.ksbutton.click();
		Thread.sleep(4000);
		String KSAction = bp.KeyStrokeAction.getText();
		String KSStatus = bp.KeyStrokeStatus.getText();
		
		System.out.println("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
		log.debug("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
		Thread.sleep(4000);
		
	}
}
