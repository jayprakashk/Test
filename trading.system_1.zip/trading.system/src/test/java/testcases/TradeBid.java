package testcases;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import actions.BidFunction;
import resources.TestBase;

public class TradeBid extends TestBase {
	
	

	@Test
	public void doBidOnPit() throws Exception {

		BidFunction bid = PageFactory.initElements(driver, BidFunction.class);


		bid.checkCaretExpand();
		Thread.sleep(2000);
		bid.listOfProduct();
		Thread.sleep(2000);
		bid.listOfPit();
		Thread.sleep(2000);
		bid.createBidOnProduct();
		Thread.sleep(2000);
		bid.checkBlotterAndStroke();
		
	}
	
	
}
