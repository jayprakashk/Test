package testcases;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import actions.OfferFuntion;
import resources.TestBase;

public class TradeOffer extends TestBase {
	
	
	
	
	@Test
	public void doOfferRequest() throws Exception {
		OfferFuntion off = PageFactory.initElements(driver, OfferFuntion.class);


		Thread.sleep(2000);
		off.checkCaretExpand();
		Thread.sleep(2000);
		off.listOfProduct();
		off.listOfPit();
		off.CreateOfferOnProduct();
		off.checkBlotterAndStroke();
		
	}
	
	
}