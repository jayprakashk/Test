package testcases;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.fintech.currency.Constants;

import pages.BrokerQuickOrderPage;
import pages.QuickOrderPage;
import resources.TestBase;

public class BrokerQuickOrder extends TestBase {

	
	Logger log = Logger.getLogger("devpinoyLogger");
	
	
	
	@Test
	public void brokerTest() throws Exception {

		
		Thread.sleep(2000);
		quickBuyBroker();
		
		Thread.sleep(3000);
		checkBlotterAndStroke();
		
	}
	
	private void quickBuyBroker() throws InterruptedException {
		BrokerQuickOrderPage br = PageFactory.initElements(driver, BrokerQuickOrderPage.class);
		QuickOrderPage qo = PageFactory.initElements(driver, QuickOrderPage.class);
		
		Thread.sleep(6000);
		br.userselection.sendKeys(Constants.traderid);
		br.userselection.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
		
		
		qo.plusbutton.click();
		Thread.sleep(2000);
		
		System.out.println("Quick order open");
		
		qo.product.sendKeys(Constants.pname);

		qo.product.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);

		System.out.println("Product selected ");
		Thread.sleep(2000);
		qo.bs.sendKeys("Buy");
		qo.bs.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
		System.out.println("Buy selected ");
		Thread.sleep(2000);
		for (int i = 0; i < 4; i++) {
			qo.ratedown.click();
			Thread.sleep(2000);
		}
		qo.savequick.click();
		System.out.println("Buy Order placed ");
		log.debug("Buy Order placed ");
		Thread.sleep(3000);
		br.OblotterProduct.click();
		System.out.println("You make order on :" + Constants.pname);
		log.debug("You make Bid on :" + Constants.pname);

		
	}

	private void checkBlotterAndStroke() throws InterruptedException {
		BrokerQuickOrderPage br = PageFactory.initElements(driver, BrokerQuickOrderPage.class);
		QuickOrderPage qo = PageFactory.initElements(driver, QuickOrderPage.class);
	
		String OBname = br.OblotterProduct.getText();
		Thread.sleep(3000);
		String OBrate = br.OblotterRate.getText();

		System.out.println("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		log.debug("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		if (Constants.pname.equals(OBname)) {
			System.out.println("Product name are displayed on order blotter are same ");
			log.debug("Product name are displayed on order blotter are same ");
		} else {
			System.out.println("Product name are displayed on order blotter are not same ");
			log.debug("Product name are displayed on order blotter are not same ");
		}
		Thread.sleep(3000);
		qo.ksbutton.click();
		Thread.sleep(3000);
		String KSAction = br.KeyStrokeAction.getText();
		String KSStatus = br.KeyStrokeStatus.getText();

		System.out.println("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
		log.debug("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
		
	}
	
}
