package testcases;

import java.text.ParseException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.fintech.currency.Constants;

import actions.BidFunction;
import pages.BidOnProductPitPage;
import resources.TestBase;

public class BidOnProductPit extends TestBase {
	BidFunction tradb = new BidFunction(driver);

	@Test
	public void bidOnProductCurrency() throws Exception {

		doBidOnGivenProduct();

	}

	private void doBidOnGivenProduct() throws InterruptedException, ParseException {
		BidOnProductPitPage bop = PageFactory.initElements(driver, BidOnProductPitPage.class);

		for (int i = 1; i < bop.leftproduct.size(); i++) {

			String name = driver.findElement(By.xpath(
					"//div[@id='productWrapper']/div[1]/div[" + i + "]/table/thead/tr/th[1]/div/*[@class='big-text']"))
					.getText();
			// System.out.println(name);
			if (name.equalsIgnoreCase(Constants.productname)) {

				try {
					WebDriverWait wait = new WebDriverWait(driver, 2);
					wait.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("//div[@id='productWrapper']/div[1]/div[" + i
									+ "]/table/thead/tr/th[1]/div/div/a/span[@class='fa fa-caret-right']")));

					WebElement caretright = driver.findElement(By.xpath("//div[@id='productWrapper']/div[1]/div[" + i
							+ "]/table/thead/tr/th[1]/div/div/a/span[@class='fa fa-caret-right']"));

					caretright.click();
					System.out.println("Caret expand");
				} catch (Exception e) {
					System.out.println("Caret Already expand");
				}

				int pitssize = driver.findElements(By
						.xpath("//div[@id='productWrapper']/div[1]/div[" + i + "]/table/tbody/tr/td/span[1]/a/span[2]"))
						.size();
				for (int j = 1; j < pitssize; j++) {
					String pits = driver.findElement(By
							.xpath("//div[@id='productWrapper']/div[1]/div[" + i + "]/table/tbody/tr[" + j + "]/td[1]"))
							.getText();
					if (pits.equalsIgnoreCase(Constants.currencyname)) {
						driver.findElement(By.xpath(
								"//div[@id='productWrapper']/div[1]/div[" + i + "]/table/tbody/tr[" + j + "]/td[4]"))
								.click();

						bop.priceset.sendKeys(Keys.SHIFT, Keys.ARROW_UP);

						tradb.createBidOnProduct();
						tradb.checkBlotterAndStroke();
					} else {
						System.out.println("Currency Not Found ");
					}
				}

			} else {
				System.out.println("Product Not Found ");
			}
		}

	}
}
