package testcases;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import actions.QuickOrderFunctionTrader;
import resources.TestBase;


public class QuickOrder extends TestBase {
	

	Logger log = Logger.getLogger("devpinoyLogger");
	public static Logger log1 = LogManager.getLogger(Tradershome.class);

	@Test

	public void checkQuickOrder() throws Exception {
		QuickOrderFunctionTrader qot = PageFactory.initElements(driver, QuickOrderFunctionTrader.class);
		

		Thread.sleep(6000);
		qot.checkQuickBuyOrderPlaces();
		Thread.sleep(2000);
		qot.checkQuickSellOrderPlaces();
		Thread.sleep(2000);
		qot.checkQuickOrderModify();
		Thread.sleep(2000);
		qot.checkQuickOrderSuspend();
		Thread.sleep(2000);
		qot.checkQuickOrderReinstante();
		Thread.sleep(2000);
		qot.checkQuickOrderCancel();

	}

	}
