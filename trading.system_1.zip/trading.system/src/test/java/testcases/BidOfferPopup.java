package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import pages.BidOfferPopupPage;
import pages.TradingBIDpage;
import resources.TestBase;

public class BidOfferPopup extends TestBase{
	
	@Test
	public void checkBidOfferPopup() throws Exception {

		checkCaretExpand();
		Thread.sleep(2000);
		checkBidPopUp();
		Thread.sleep(2000);
		checkOfferPopup();
		
	}

	private void checkCaretExpand() throws InterruptedException {
		TradingBIDpage tb = PageFactory.initElements(driver, TradingBIDpage.class);
		Thread.sleep(2000);
		try {
			WebDriverWait wait = new WebDriverWait(driver, 2);
			wait.until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//div[@id='productWrapper']/div[1]/div[1]/table/thead/tr/th[1]/div/div/a/span[@class='fa fa-caret-right']")));
			
			tb.caretright.click();
			System.out.println("Caret expand");
		} catch (Exception e) {
			System.out.println("Caret Already expand");
		}
		
	}

	private void checkBidPopUp() {
		BidOfferPopupPage bo = PageFactory.initElements(driver, BidOfferPopupPage.class);
		bo.firstpitbid.click();
		System.out.println("Bid popup open ");
		log.debug("Bid popup open ");
		System.out.println(bo.rate.getAttribute("value"));
		bo.crospop.click();
		System.out.println("Bid popup closed ");
		log.debug("Bid popup closed ");
	}

	private void checkOfferPopup() {
		BidOfferPopupPage bo = PageFactory.initElements(driver, BidOfferPopupPage.class);
		bo.firstOffer.click();
		System.out.println("Offer popup open ");
		log.debug("Offer popup open ");
		System.out.println(bo.rate.getAttribute("value"));
		bo.crospop.click();
		System.out.println("Offer popup closed ");
		log.debug("Offer popup closed ");
	}

}
