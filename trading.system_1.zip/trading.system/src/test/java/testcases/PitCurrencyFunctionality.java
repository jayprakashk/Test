package testcases;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import pages.PitonProductpage;
import resources.TestBase;

public class PitCurrencyFunctionality extends TestBase {

	Logger log = Logger.getLogger("devpinoyLogger");
	String log4jConfPath = "Log4j.properties";
	
	

	@Test
	public void checkCurrency() throws Exception {
		PropertyConfigurator.configure(log4jConfPath);

		log.debug("logined done");
		Thread.sleep(2000);
		checkCaretAtProduct();
		Thread.sleep(2000);
		checkListOfProductBeforeHiding();
		Thread.sleep(2000);
		uncheckAllCurrency();
		Thread.sleep(2000);
		checkListOfProductAfterHiding();
		Thread.sleep(2000);
		unHideProduct();
		Thread.sleep(2000);
		checkAllCurrency();
	}
	
	private void checkCaretAtProduct() {
		PitonProductpage pits = PageFactory.initElements(driver, PitonProductpage.class);
		for (int i = 0; i < pits.allpits.size(); i++) {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 20);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class='fa fa-caret-down']")));

				pits.caretdown.click();
				System.out.println("Currency list collaps");
				log.debug("Currency list collaps");
			} catch (Exception e) {

				System.out.println("Currency list already collaps");
				log.debug("Currency list already collaps");
			}
		}

	}

	private void checkListOfProductBeforeHiding() {
		PitonProductpage pits = PageFactory.initElements(driver, PitonProductpage.class);
		for (int i = 0; i < pits.leftsideproduct.size(); i++) {
			System.out.println("List of left side products before hiding a product are:\n"
					+ pits.leftsideproduct.get(i).getText());
			log.debug("List of left side products before hiding a product are:\n"
					+ pits.leftsideproduct.get(i).getText());
		}
	}	
	
	private void uncheckAllCurrency() throws InterruptedException {
		PitonProductpage pits = PageFactory.initElements(driver, PitonProductpage.class);
		pits.pitsetting.click();
		Thread.sleep(2000);
		System.out.println("Open pits setting");
		log.debug("Open pits setting");
		pits.nonfilter.click();
		Thread.sleep(2000);
		System.out.println("uncheck all currency");
		log.debug("uncheck all currency");
		pits.savefilter.click();
		Thread.sleep(12000);
		System.out.println("Save by uncheck all currency");
		log.debug("Save by uncheck all currency");
	}
	
	private void checkListOfProductAfterHiding() {
		PitonProductpage pits = PageFactory.initElements(driver, PitonProductpage.class);
		for (int i = 0; i < pits.leftsideproduct.size(); i++) {
			System.out.println(
					"List of left side products after hiding a product are:\n" + pits.leftsideproduct.get(i).getText());
			log.debug(
					"List of left side products after hiding a product are:\n" + pits.leftsideproduct.get(i).getText());
		}
		pits.mainsetting.click();
		}
	private void unHideProduct() throws InterruptedException {
		PitonProductpage pits = PageFactory.initElements(driver, PitonProductpage.class);
		Thread.sleep(2000);
		System.out.println("Open main products list setting  ");
		log.debug("Open main products list setting  ");

		pits.selectall.click();
		Thread.sleep(2000);
		System.out.println("select all products groups");
		log.debug("select all products groups");

		pits.savemainsetting.click();
		Thread.sleep(12000);
		System.out.println("Main setting saved to show all product");
		log.debug("Main setting saved to show all product");
		
	}
		
	private void checkAllCurrency() throws InterruptedException {
		PitonProductpage pits = PageFactory.initElements(driver, PitonProductpage.class);
		Thread.sleep(3000);
		pits.pitsetting.click();
		System.out.println("Open pits setting");
		log.debug("Open pits setting");
//		pits.allfilter.click();
//		Thread.sleep(3000);
//		System.out.println("Select all pits setting");
//		log.debug("Select all pits setting");
		
	//	pits.savefilter.click();
		Thread.sleep(2000);
//		System.out.println("Pits setting Saved");
//		log.debug("Pits setting Saved");
	}
		
		

	}
