package testcases;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import pages.BidPlusPage;
import resources.TestBase;

public class BidPlus extends TestBase {

	@Test
	public void doBidPlus() throws Exception {

		checkCaretExpand();
		createBidPlus();
		Thread.sleep(2000);
		expandToCheckAllBid();
		

	}

	private void expandToCheckAllBid() {
		BidPlusPage bp = PageFactory.initElements(driver, BidPlusPage.class);
		bp.expand.click();
	}

	private void checkCaretExpand() {
		BidPlusPage bp = PageFactory.initElements(driver, BidPlusPage.class);
		try {
			WebDriverWait wait = new WebDriverWait(driver, 1);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(
					"//div[@id='productWrapper']/div[1]/div[1]/table/thead/tr/th[1]/div/div/a/span[@class='fa fa-caret-right']")));
			bp.caretright.click();
			System.out.println("Caret expand");
			log.debug("Caret expand");
		} catch (Exception e) {
			System.out.println("Caret Already expand");
			log.debug("Caret Already expand");
		}
	}

	private void createBidPlus() throws InterruptedException {
		BidPlusPage bp = PageFactory.initElements(driver, BidPlusPage.class);
		for (int i = 0; i < 6; i++) {
			bp.firstpitbid.click();
			bp.rateplus.click();
			Thread.sleep(2000);
			bp.bidpuls.click();
			try {
				WebDriverWait wait = new WebDriverWait(driver, 2);
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert = driver.switchTo().alert();
				alert.accept();
				System.out.println("Alert accepted ");
				log.debug("Alert accepted ");
			} catch (Exception e) {
				System.out.println("No alert displayed");
				log.debug("No alert displayed");
			}
			System.out.println("Bid Plus palced ");
			log.debug("Bid Plus palced ");
			Thread.sleep(3000);
			checkBlotterAndStrike();
		}
	}

	private void checkBlotterAndStrike() throws InterruptedException {
		BidPlusPage bp = PageFactory.initElements(driver, BidPlusPage.class);
		Thread.sleep(2000);
		bp.OblotterProduct.click();

		String OBname = bp.OblotterProduct.getText();
		Thread.sleep(3000);
		String OBrate = bp.OblotterRate.getText();

		System.out.println("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		log.debug("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		Thread.sleep(2000);
		bp.ksbutton.click();
		Thread.sleep(4000);
		String KSAction = bp.KeyStrokeAction.getText();
		String KSStatus = bp.KeyStrokeStatus.getText();
		
		System.out.println("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
		log.debug("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);

	
	}
}
