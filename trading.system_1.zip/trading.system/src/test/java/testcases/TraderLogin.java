package testcases;

import org.testng.annotations.Test;

import actions.HomePageCheck;
import actions.Login;
import resources.TestBase;

public class TraderLogin extends TestBase{

//	Logger log = Logger.getLogger("devpinoyLogger");
//	String log4jConfPath = "Log4j.properties";
	

	@Test
	public void loginLogoutUser() throws Exception {
		
		Login ln=new Login(driver);
		HomePageCheck ho = new HomePageCheck(driver);

		ln.dologin();
		Thread.sleep(9000);
		ho.verifyHomeTitle();
		Thread.sleep(3000);


	}

	
}
