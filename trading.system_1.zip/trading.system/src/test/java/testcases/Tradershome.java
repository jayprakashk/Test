package testcases;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import actions.Dashboardcheck;
import actions.Login;
import resources.TestBase;


public class Tradershome extends TestBase {

	Logger log = Logger.getLogger("devpinoyLogger");
	String log4jConfPath = "Log4j.properties";


	@Test

	public void dasboard() throws Exception {
		PropertyConfigurator.configure(log4jConfPath);
		Dashboardcheck das = PageFactory.initElements(driver, Dashboardcheck.class);
		Login ln=new Login(driver);
		
//		ln.dologin();
		Thread.sleep(3000);
		das.checkServerConnectionStstus();
		Thread.sleep(1000);
		das.checkButtomPanel();
		Thread.sleep(1000);
		das.checkMainSetting();
		Thread.sleep(1000);
		das.checkListOfProduct();
		Thread.sleep(1000);
		das.checkApplicationStstus();
		Thread.sleep(1000);
		das.checkUserProfleDetails();
		
		Thread.sleep(1000);
		das.checkWithoutEmptyLiquidity();
		Thread.sleep(1000);
		das.checkWithEmptyLiquidity();
		Thread.sleep(1000);
		das.checkThreeDot();
		Thread.sleep(1000);
		das.userClickCountCheck();
		Thread.sleep(1000);
		das.quickOrderCheck();

	}

}
