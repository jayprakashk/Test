package utilities;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;

public class TearDown {
	static WebDriver driver ;
	static public Logger log = Logger.getLogger("devpinoyLogger");
	static public String log4jConfPath = "Log4j.properties";
@AfterSuite
	public void Teardown() {

		// Logger log = Logger.getLogger("devpinoyLogger");
		// String log4jConfPath = "Log4j.properties";
		// PropertyConfigurator.configure(log4jConfPath);

		if (driver != null)
			driver.quit();
		System.out.println("Browser closed ");
		log.debug("Browser closed");
	}
}
