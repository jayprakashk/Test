package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BidPlusPage {
	
WebDriver driver;
	
	public BidPlusPage(WebDriver driver) {
		this.driver=driver;
		
	}
	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/thead/tr/th[1]/div/div/a/span[@class='fa fa-caret-right']")
	public WebElement caretright;
	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/thead/tr/th[1]/div/div/a/span[@class='fa fa-caret-down']")
	public WebElement caretdown;

	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/tbody/tr[3]/td[4]")
	public WebElement firstpitbid;
	
	@FindBy(xpath="//a[contains(text(),'Bid +')]")
	public WebElement bidpuls;
	
	@FindBy(css="#txtBestPrice")
	public WebElement priceset;
	
	@FindBy (xpath="//tr[@id='bid-row']/td/div/div[1]/div[2]/div/span/a[@id='orderPricePlus']")
	public WebElement rateplus;
	
	@FindBy (xpath="//tr[@id='bid-row']/td/div/div[1]/div[2]/div/span/a[@id='orderPriceMinus']")
	public WebElement rateminus;
	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/tbody/tr[3]/td[1]/span/a/span[1]")
	public WebElement expand;
	
	@FindBy (xpath="//div[@id='trobmarketData']/table/tbody/tr[1]/td[5]")
	public WebElement OblotterRate;
	
	@FindBy (xpath="//div[@id='trobmarketData']/table/tbody/tr[1]/td[3]")
	public WebElement OblotterProduct;
	
	@FindBy (xpath="//a[contains(text(),'Key Stroke')]")
	public WebElement ksbutton;
	
	@FindBy (xpath="//div[@id='trksmarketData']/table/tbody/tr[1]/td[3]")
	public WebElement KeyStrokeAction;
	
	@FindBy (xpath="//div[@id='trksmarketData']/table/tbody/tr[1]/td[4]")
	public WebElement KeyStrokeStatus;
	
}
