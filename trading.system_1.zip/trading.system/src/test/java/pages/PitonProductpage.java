package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PitonProductpage {
	
	
	@FindBy (xpath="//table[@id='table_1']//div//span[@class='fa fa-caret-right']")
	public WebElement caretright;
	
	@FindBy (xpath="//span[@class='fa fa-caret-down']")
	public WebElement caretdown;
	
	@FindBy (id="productgroup_1")
	public List<WebElement> allpits;
		
	@FindBy (css="#pitFilterIco")
	public WebElement pitsetting;
	
	@FindBy (css="#filterSelectNone")
	public WebElement nonfilter;
	
	@FindBy (css="#filterSelectAll")
	public WebElement allfilter;
	
	@FindBy (css="#filterSave")
	public WebElement savefilter;
	
	@FindBy(xpath="//div[@id='column0']")
	public List<WebElement> leftsideproduct;
	
	@FindBy(xpath="//div[@id='column1']")
	public List<WebElement> righsidelist;
	
	@FindBy(css="#mainGroupFilterSetting")
	public WebElement mainsetting;
	
	
	@FindBy(css="#filterSelectAllSettings")
	public WebElement selectall;
	
	
	@FindBy(id="groupFilterSave")
	public WebElement savemainsetting;
	
}
