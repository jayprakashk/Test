package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TradeOfferPage {
WebDriver driver;
	
	public TradeOfferPage(WebDriver driver) {
		this.driver=driver;
		
	}
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/thead/tr/th[1]/div/div/a/span[@class='fa fa-caret-right']")

	public WebElement caretright;
	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/thead/tr/th[1]/div/div/a/span[@class='fa fa-caret-down']")

	public WebElement caretdown;
	
	@FindBy (id="productgroup_1")
	public WebElement allpits;
	
	//all product listed on page
	@FindBy (className="dragHandler")
	public List<WebElement> list;
	
	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/tbody")
	public List<WebElement> alist;
	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/tbody/*[@class='has-child sortit']")
	public List<WebElement> pitlist;
	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/tbody/*[@class='has-child sortit']/td/span[@class='inlined']")
	public List<WebElement> qww;
	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/tbody/*[@class='has-child sortit']/td/span/a/span[@class='timer']")
	public List<WebElement> curlist;
	
	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/tbody/tr[4]/td[5]")
	
	public WebElement firstOffer;
	
	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/tbody/tr[4]/td[1]")
	public WebElement productname;
	
		
	@FindBy (css="#txtBestPrice")
	public WebElement priceset;
	
	
	@FindBy (css="#orderSubmit")
	public WebElement bidsubmit;
	
	@FindBy (xpath="//div[@class='btnBlock one']")
	public WebElement modifybid;
	
	@FindBy (xpath="//div[@id='trobmarketData']/table/tbody/tr[1]/td[5]")
	public WebElement OblotterRate;
	
	@FindBy (xpath="//div[@id='trobmarketData']/table/tbody/tr[1]/td[3]")
	public WebElement OblotterProduct;
	
	@FindBy (xpath="//a[contains(text(),'Key Stroke')]")
	public WebElement ksbutton;
	
	@FindBy (xpath="//div[@id='trksmarketData']/table/tbody/tr[1]/td[3]")
	public WebElement KeyStrokeAction;
	
	@FindBy (xpath="//div[@id='trksmarketData']/table/tbody/tr[1]/td[4]")
	public WebElement KeyStrokeStatus;
	
	
	
	

}
