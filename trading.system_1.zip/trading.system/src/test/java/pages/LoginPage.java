package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import resources.TestBase;

public class LoginPage extends TestBase{

	
	WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		
	}
	


	@FindBy(id="UserEmail")
	public static WebElement username;
	
	@FindBy(id="UserPassword")
	public static WebElement password;
	
	
	@FindBy(id="btnSignIn")
	public WebElement signin;
	
	
	@FindBy(id="btnOkLogout")
	public WebElement yesbutton;
	
	@FindBy(id="passwordExpiryMessageModalButton")
	public WebElement okbutton; 
	
	@FindBy(css="#userName")
	public WebElement clickonprofile;
	
	@FindBy(xpath="//a[@class='logout']")
	public WebElement logout;
	
	
	public static void setemail(String email) {
		username.sendKeys(email);
	}
	
	public static void setpassword(String pass) {
		password.sendKeys(pass);
	}
	
	public void loginbutton() {
		signin.click();
	}
	
	public void alertyes() {
		yesbutton.click();
	}
	
	public void openprofile() {
		clickonprofile.click();
	}
	
	public void logout() {
		logout.click();
	}
}
