package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class QuickOrderPage {
WebDriver driver;
	
	
	public QuickOrderPage(WebDriver driver) {
		this.driver=driver;
		
	}
		
	@FindBy(id="add-table")
	public WebElement plusbutton;
	
	
	@FindBy(css="#quickddlTraderInput")
	public WebElement Accouname;
	
	@FindBy(css="#quickddlProductInput")
	public WebElement product;
	
	@FindBy(css="#quickddlBSInput")
	public WebElement bs;
	
	
	@FindBy(xpath="//div[@class='sol-container sol-selection-bottom sol-active']//div[@class='sol-selection-container']")
	public WebElement allproduct;
	
	
	@FindBy(xpath="//div[@class='sol-container sol-selection-bottom sol-active']//div[@class='sol-selection']")
	public List<WebElement> buysell;
	
	
	@FindBy(xpath="//form[@id='quickOrderForm']//a[@id='orderPricePlus']//i[@class='fa fa-caret-up']")
	public WebElement rateup;

	@FindBy(xpath="//form[@id='quickOrderForm']//a[@id='orderPriceMinus']//i[@class='fa fa-caret-down']")
	public WebElement ratedown;
	
	
		
	@FindBy(xpath="//a[@id='quickOrderSubmit']//span[@class='fa fa-arrow-right']")
	public WebElement savequick;
	
	@FindBy (xpath="//div[@id='trobmarketData']/table/tbody/tr[1]/td[5]")
	public WebElement OblotterRate;
	
	@FindBy (xpath="//div[@id='trobmarketData']/table/tbody/tr[1]/td[3]")
	
	public WebElement OblotterProduct;
	
	@FindBy (xpath="//div[@id='trobmarketData']/table/tbody/tr[1]/td[1]/span[3]")
	public WebElement Modify;
	
	@FindBy (xpath="//div[@id='trobmarketData']/table/tbody/tr[1]/td[1]/span[2]")
	public WebElement suspend;
	
	@FindBy (xpath="//div[@id='trobmarketData']/table/tbody/tr[1]/td[1]/span[1]/*[@class='stopOrderBlotter']")
	public WebElement canceled;
	
	@FindBy (xpath="//a[@id='obOrderIcePlus']//i[@class='fa fa-caret-up']")
	public WebElement totalinc;
	
	@FindBy (css="#obModifyOrderSubmit")
	public WebElement msave;
	
	
	@FindBy (xpath="//a[contains(text(),'Key Stroke')]")
	public WebElement ksbutton;
	
	@FindBy (xpath="//div[@id='trksmarketData']/table/tbody/tr[1]/td[3]")
	public WebElement KeyStrokeAction;
	
	@FindBy (xpath="//div[@id='trksmarketData']/table/tbody/tr[1]/td[4]")
	public WebElement KeyStrokeStatus;
	
	
}
