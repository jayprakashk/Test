package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BrokerQuickOrderPage {

	WebDriver driver;
	
	public BrokerQuickOrderPage(WebDriver driver) {
		this.driver=driver;
		
	}
	
	@FindBy(xpath="//input[@placeholder='Select value']")
	public WebElement userselection;
	
	@FindBy (xpath="//div[@id='brobmarketData']/table/tbody/tr[1]/td[5]")
	public WebElement OblotterRate;
	
	@FindBy (xpath="//div[@id='brobmarketData']/table/tbody/tr[1]/td[3]")
	
	public WebElement OblotterProduct;
	
	@FindBy (xpath="//a[contains(text(),'Key Stroke')]")
	public WebElement ksbutton;
	
	@FindBy (xpath="//div[@id='brksmarketData']/table/tbody/tr[1]/td[3]")
	public WebElement KeyStrokeAction;
	
	@FindBy (xpath="//div[@id='brksmarketData']/table/tbody/tr[1]/td[4]")
	public WebElement KeyStrokeStatus;
	
	
}
