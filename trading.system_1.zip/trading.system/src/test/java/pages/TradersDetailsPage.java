package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TradersDetailsPage {
	
	
	WebDriver driver;
	
	
	public TradersDetailsPage(WebDriver driver) {
		this.driver=driver;
		
	}
	
			
		@FindBy(css="#mainGroupFilterSetting")
		public WebElement mainsetting;
		
		
		@FindBy(css="#filterSelectAllSettings")
		public WebElement selectall;
		
		
		@FindBy(id="groupFilterSave")
		public WebElement savemainsetting;
		
		@FindBy(id="filterSelectNoneSettings")
		public WebElement selectednon;
		
		@FindBy(xpath="//body//span[5]")
		public WebElement openlistofproduct;
		
		@FindBy(className="allowed")
		public List<WebElement> allowedproduct;
		
		@FindBy(className="notallowed")
		public List<WebElement> notallowedproduct;
		
				
		@FindBy(css="#allowedProducts")
		public List<WebElement> allproductlist;
		
		
		@FindBy(id="userName")
		public WebElement clickonprofile;
		
		
		@FindBy(xpath="//ul[@class='sub-menu']")
		public List<WebElement> profilemenu;
		
		
		@FindBy(xpath="//a[@class='btnMainHead']")
		public WebElement threedot;
		
		@FindBy(xpath="//*[@id='ServerInfo']/child::a[2]")
		public WebElement hotdot;
		
		@FindBy(xpath="//div[@id='hotkeyPopup']//span[contains(text(),'×')]")
		public WebElement closehotdot;
		
				
		@FindBy(xpath="//*[@id='ServerInfo']/child::i[1]")
		public WebElement savedot;
		
		@FindBy(css="	#toastMsg")
		public WebElement toastmsg;
	
				
		@FindBy(xpath="//*[@id='ServerInfo']/child::a[1]") 
		public WebElement helpdot;
		
		@FindBy(xpath="//div[@id='information']//span[contains(text(),'×')]")
		public WebElement closehelpdot;
		
		@FindBy(xpath="//span[@class='fa fa-caret-down']")
		public WebElement caretdown;
		
//		@FindBy(xpath="//div[@id='information']//span[contains(text(),'×')]")
//		public WebElement closehelpdot;
//		
//		@FindBy(id="add-table")
//		public WebElement plusbutton;
		
		@FindBy(css="#add-table")
		public WebElement plusbutton;
		
		
		@FindBy(xpath="//span[@class='icon-crown']")
		public WebElement userclickcount;
		
		@FindBy(className="closePopupBtn")
		public WebElement userclickcountclosed;
		
//		@FindBy(xpath="//div[@id='userCountModalHeader']//a[@class='closePopupBtn']")
//		public WebElement userclickcountclosed;
		

		
		@FindBy(xpath="//label[@title='Skip empty liquidity']//span[@class='slider round']")
		public WebElement skipempty;
		
		
				
		@FindBy(xpath="//i[@title='Application status.']")
		public WebElement applicationstatus;
		
		
		@FindBy(xpath="//i[@id='ServerConnectionStatus']")
		public WebElement ServerConnectionStatus;
		
		
		@FindBy(xpath="//span[@class='dots']")
		public WebElement panneldot;
		
		@FindBy(css="#dragIcon")
		public WebElement unhidepannel;
		
		@FindBy(xpath="//div[@id='column0']")
		public List<WebElement> leftsideproduct;
		
		@FindBy(xpath="//div[@id='column1']")
		public List<WebElement> righsidelist;
		
		
		@FindBy(id="userClickCountCurrencies")
		public List<WebElement> currencylist;
		
		
		@FindBy(css="#txtBestPrice")
		public WebElement rateentry;
		
		
		@FindBy(id="quickOrderSubmit")
		public WebElement quicksubmit;
		
		@FindBy(xpath="//a[contains(text(),'Profile')]")
		public WebElement profiledetail;
		
		@FindBy(xpath="//a[@class='first']")
		public WebElement homeprofile;
		
		
		
		
		
				
		public void checkmainsetting() {
			
			mainsetting.click();
		}
		
		public void selecallproduct() {
			selectall.click();
		}
		
		public void savesetting() {
			savemainsetting.click();
		}
		
		public void selectnonproduct() {
			selectednon.click();
		}
		
		public void savenonproduct() {
			savemainsetting.click();
		}
		
		
}
	
	
