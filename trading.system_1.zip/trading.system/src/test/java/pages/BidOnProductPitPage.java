package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BidOnProductPitPage {
	
WebDriver driver;
	
	public BidOnProductPitPage(WebDriver driver) {
		this.driver=driver;
		
	}

	@FindBy (xpath="//*[@column='column0']")
	public List<WebElement> leftproduct;
	
	@FindBy (css="#txtBestPrice")
	public WebElement priceset;
	
	
	
}
