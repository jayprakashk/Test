package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BidOfferPopupPage {
	
WebDriver driver;
	
	public BidOfferPopupPage(WebDriver driver) {
		this.driver=driver;
		
	}
	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/tbody/tr[1]/td[4]")
	public WebElement firstpitbid;

	
	@FindBy (xpath="//div[@id='productWrapper']/div[1]/div[1]/table/tbody/tr[1]/td[5]")
	public WebElement firstOffer;
	
	@FindBy (xpath="//i[@class='fas fa-times-circle']")
	public WebElement crospop;
	
	@FindBy (css="#txtBestPrice")
	public WebElement rate;
	
	
	
}
