package actions;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import pages.TradeOfferPage;
import resources.TestBase;

public class OfferFuntion extends TestBase{
	WebDriver driver;

	public OfferFuntion(WebDriver driver) {
		this.driver = driver;
	}
	

	public void checkCaretExpand() {
		TradeOfferPage ob = PageFactory.initElements(driver, TradeOfferPage.class);
		try {
			WebDriverWait wait = new WebDriverWait(driver, 2);
			wait.until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//div[@id='productWrapper']/div[1]/div[1]/table/thead/tr/th[1]/div/div/a/span[@class='fa fa-caret-right']")));

			ob.caretright.click();
			System.out.println("Caret expand");
			log.debug("Caret expand");

		} catch (Exception e) {
			System.out.println("Caret Already expand");
			log.debug("Caret Already expand");

		}
	}
	public void listOfProduct() {
		TradeOfferPage ob = PageFactory.initElements(driver, TradeOfferPage.class);
		System.out.println("List of product Display are:\n ");
		log.debug("List of product Display are:\n ");
		
		for (int j = 0; j < ob.list.size(); j++) {
			// System.out.println(ob.list.size());
			System.out.println(ob.list.get(j).getText());
			log.debug(ob.list.get(j).getText());

		}
	}
	
	public void listOfPit() {
		TradeOfferPage ob = PageFactory.initElements(driver, TradeOfferPage.class);
	System.out.println("List of pits Display are:\n ");
	log.debug("List of pits Display are:\n ");
	for (int j = 0; j < ob.curlist.size(); j++) {
		System.out.println(ob.curlist.get(j).getText());
		log.debug(ob.curlist.get(j).getText());

	}	
	
}
		

	public void CreateOfferOnProduct() throws InterruptedException {
		TradeOfferPage ob = PageFactory.initElements(driver, TradeOfferPage.class);
		Thread.sleep(3000);
		ob.firstOffer.click();
		System.out.println("click for Offer");
		log.debug("click for Offer");
		Thread.sleep(2000);
		ob.priceset.sendKeys(Keys.SHIFT, Keys.ARROW_UP);
	

		Thread.sleep(3000);
		if (ob.bidsubmit.isDisplayed()) {
			ob.bidsubmit.click();
			Thread.sleep(3000);
		} else {
			ob.modifybid.click();
		}
	
		try {
			WebDriverWait wait = new WebDriverWait(driver, 2);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.accept();
			System.out.println("Alert accepted ");
			log.debug("Alert accepted ");
		} catch (Exception e) {
			System.out.println("No alert displayed");
			log.debug("No alert displayed");
		}

	}
		
	public void checkBlotterAndStroke() throws InterruptedException {
		TradeOfferPage ob = PageFactory.initElements(driver, TradeOfferPage.class);
		String Pname = ob.productname.getText();
		ob.OblotterProduct.click();
		System.out.println("You make Bid on :" + Pname);
		log.debug("You make Bid on :" + Pname);
		Thread.sleep(3000);

		String OBname = ob.OblotterProduct.getText();
		Thread.sleep(3000);
		String OBrate = ob.OblotterRate.getText();

		System.out.println("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		log.debug("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		if (Pname.equals(OBname)) {
			System.out.println("Product name are displayed on order blotter are same ");
			log.debug("Product name are displayed on order blotter are same ");
		} else {
			System.out.println("Product name are displayed on order blotter are not same ");
			log.debug("Product name are displayed on order blotter are not same ");
		}
		Thread.sleep(3000);
		ob.ksbutton.click();
		String KSAction = ob.KeyStrokeAction.getText();
		String KSStatus = ob.KeyStrokeStatus.getText();

		System.out.println("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
		log.debug("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
	}

}
