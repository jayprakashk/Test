package actions;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fintech.currency.Constants;

import pages.QuickOrderPage;
import resources.TestBase;

public class QuickOrderFunctionTrader extends TestBase{
	WebDriver driver;
	public QuickOrderFunctionTrader(WebDriver driver) {
		this.driver=driver;
	}

	
	
	public void checkQuickBuyOrderPlaces() throws InterruptedException {
		QuickOrderPage qo = PageFactory.initElements(driver, QuickOrderPage.class);
		Thread.sleep(3000);
		qo.plusbutton.click();
		Thread.sleep(2000);
		System.out.println("Quick order open");
		qo.product.sendKeys(Constants.pname);

		qo.product.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);

		System.out.println("Product selected ");
		Thread.sleep(2000);
		qo.bs.sendKeys("Buy");
		qo.bs.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
		System.out.println("Buy selected ");
		Thread.sleep(2000);
		for (int i = 0; i < 4; i++) {
			qo.ratedown.click();
			Thread.sleep(2000);
		}
		qo.savequick.click();
		System.out.println("Buy Order placed ");
		log.debug("Buy Order placed ");
		Thread.sleep(3000);
		qo.OblotterProduct.click();
		System.out.println("You make order on :" + Constants.pname);
		log.debug("You make Bid on :" + Constants.pname);

		Thread.sleep(3000);

		String OBname = qo.OblotterProduct.getText();
		Thread.sleep(3000);
		String OBrate = qo.OblotterRate.getText();

		System.out.println("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		log.debug("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		if (Constants.pname.equals(OBname)) {
			System.out.println("Product name are displayed on order blotter are same ");
			log.debug("Product name are displayed on order blotter are same ");
		} else {
			System.out.println("Product name are displayed on order blotter are not same ");
			log.debug("Product name are displayed on order blotter are not same ");
		}

		qo.ksbutton.click();
		String KSAction = qo.KeyStrokeAction.getText();
		String KSStatus = qo.KeyStrokeStatus.getText();

		System.out.println("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
		log.debug("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
	}

	public void checkQuickSellOrderPlaces() throws InterruptedException {
		QuickOrderPage qo = PageFactory.initElements(driver, QuickOrderPage.class);
		qo.plusbutton.click();
		Thread.sleep(2000);
		System.out.println("Quick order open");
		log.debug("Quick order open");

		qo.product.sendKeys(Constants.pname);

		qo.product.sendKeys(Keys.ARROW_UP, Keys.ENTER);

		System.out.println("Product selected ");
		Thread.sleep(2000);
		qo.bs.sendKeys("Sell");
		qo.bs.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
		System.out.println("Sell selected ");
		Thread.sleep(2000);
		for (int i = 0; i < 4; i++) {
			qo.rateup.click();
			Thread.sleep(2000);
		}
		qo.savequick.click();
		System.out.println("Sell Order placed ");
		log.debug("Sell Order placed ");
		Thread.sleep(3000);
		qo.OblotterProduct.click();
		System.out.println("You make Order on :" + Constants.pname);
		log.debug("You make Bid on :" + Constants.pname);
		Thread.sleep(3000);

		String OBname = qo.OblotterProduct.getText();
		Thread.sleep(3000);
		String OBrate = qo.OblotterRate.getText();

		System.out.println("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		log.debug("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		if (Constants.pname.equals(OBname)) {
			System.out.println("Product name are displayed on order blotter are same ");
			log.debug("Product name are displayed on order blotter are same ");
		} else {
			System.out.println("Product name are displayed on order blotter are not same ");
			log.debug("Product name are displayed on order blotter are not same ");
		}

		qo.ksbutton.click();
		String KSAction = qo.KeyStrokeAction.getText();
		String KSStatus = qo.KeyStrokeStatus.getText();

		System.out.println("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
		log.debug("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
	}

	public void checkQuickOrderCancel() throws InterruptedException {
		QuickOrderPage qo = PageFactory.initElements(driver, QuickOrderPage.class);
		System.out.println("Open for cancel the order");
		log.debug("Open for cancel the order");
		qo.canceled.click();
		System.out.println("Order get Cancelled ");
		log.debug("Order get Cancelled");
		Thread.sleep(2000);
		qo.ksbutton.click();
		String KSAction = qo.KeyStrokeAction.getText();
		String KSStatus = qo.KeyStrokeStatus.getText();
		Thread.sleep(2000);
		System.out.println("Action and status displayed in Key stroke after cancellation " + KSAction + " with status  "
				+ KSStatus);
		log.debug("Action and status displayed in Key stroke after cancellation  " + KSAction + " with status  "
				+ KSStatus);
		Thread.sleep(2000);
	}

	public void checkQuickOrderSuspend() throws InterruptedException {
		QuickOrderPage qo = PageFactory.initElements(driver, QuickOrderPage.class);
		System.out.println("Open for Suspend the order");
		log.debug("Open for Suspend the order");
		qo.suspend.click();
		try {
			WebDriverWait wait = new WebDriverWait(driver, 2);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.accept();
			System.out.println("Alert accepted and order get suspended ");
			log.debug("Alert accepted and order get suspended ");

		} catch (Exception e) {
			System.out.println("No alert displayed");
			log.debug("No alert displayed");
		}
		qo.ksbutton.click();
		Thread.sleep(2000);
		String KSAction = qo.KeyStrokeAction.getText();
		String KSStatus = qo.KeyStrokeStatus.getText();

		System.out.println(
				"Action and status displayed in Key stroke after Suspend " + KSAction + " with status  " + KSStatus);
		log.debug("Action and status displayed in Key stroke after Suspend  " + KSAction + " with status  " + KSStatus);
	}

	public void checkQuickOrderModify() throws InterruptedException {
		QuickOrderPage qo = PageFactory.initElements(driver, QuickOrderPage.class);
		qo.Modify.click();
		System.out.println("Open for Modification of order");
		log.debug("Open for Modification of order");
		for (int i = 0; i < 4; i++) {
			qo.totalinc.click();
			Thread.sleep(2000);
		}
		System.out.println("Total count get changed");
		log.debug("Total count get changed");
		qo.msave.click();
		Thread.sleep(2000);
		System.out.println("Modification done ");
		log.debug("Modification done ");
		qo.ksbutton.click();
		Thread.sleep(2000);
		String KSAction = qo.KeyStrokeAction.getText();
		String KSStatus = qo.KeyStrokeStatus.getText();

		System.out.println("Action and status displayed in Key stroke after modification " + KSAction + " with status  "
				+ KSStatus);
		log.debug("Action and status displayed in Key stroke after modification  " + KSAction + " with status  "
				+ KSStatus);
	}

	public void checkQuickOrderReinstante() throws InterruptedException {
		QuickOrderPage qo = PageFactory.initElements(driver, QuickOrderPage.class);
		System.out.println("Click for Reinstante the order");
		log.debug("Click for Reinstante the order");
		qo.suspend.click();

		try {
			WebDriverWait wait = new WebDriverWait(driver, 2);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.accept();
			System.out.println("Alert accepted and order get Reinstante ");
			log.debug("Alert accepted and order get Reinstante ");

		} catch (Exception e) {
			System.out.println("No alert displayed");
			log.debug("No alert displayed");
		}
		Thread.sleep(2000);
		qo.ksbutton.click();
		String KSAction = qo.KeyStrokeAction.getText();
		String KSStatus = qo.KeyStrokeStatus.getText();

		System.out.println(
				"Action and status displayed in Key stroke after Reinstante " + KSAction + " with status  " + KSStatus);
		log.debug("Action and status displayed in Key stroke after Reinstante  " + KSAction + " with status  "
				+ KSStatus);
	}

}
