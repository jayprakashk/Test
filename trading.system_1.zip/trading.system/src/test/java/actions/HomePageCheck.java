package actions;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.fintech.currency.Constants;

import pages.LoginPage;

public class HomePageCheck {
	public LoginPage lp;
	static WebDriver driver;
	static public Logger log = Logger.getLogger("devpinoyLogger");
	static public String log4jConfPath = "Log4j.properties";
	

	
	public HomePageCheck(WebDriver driver) {
		HomePageCheck.driver=driver;
		
	}
	
public void verifyHomeTitle() {
		
		try {
			Assert.assertEquals(driver.getTitle(), Constants.title);

			log.debug("Title verified successful for XP Securities - Investments in Global Assets");
		} catch (AssertionError e) {
			System.out.println("Actual Title displayed :" + driver.getTitle());
			log.debug("Actual Title displayed :" + driver.getTitle());
		}
	}

	

}
