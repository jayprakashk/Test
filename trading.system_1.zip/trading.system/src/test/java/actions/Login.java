package actions;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fintech.currency.Constants;

import pages.LoginPage;
import resources.TestBase;

public class Login extends TestBase {
	WebDriver driver;
	static public Logger log = Logger.getLogger("devpinoyLogger");
	static public String log4jConfPath = "Log4j.properties";

	public Login(WebDriver driver) {
		this.driver=driver;
	}

	public void dologin() throws InterruptedException {

		LoginPage login = PageFactory.initElements(driver, LoginPage.class);

		LoginPage.setemail(Constants.traderid);
		LoginPage.setpassword(Constants.traderpass);
		Thread.sleep(2000);
		log.debug("Credential entered");
		System.out.println("Credential entered ");
		login.loginbutton();
		Thread.sleep(2000);
		System.out.println("Click on Login button  ");
		log.debug("Click on Login button");

		try {
			String msg = driver.findElement(By.id("userMessage")).getText();
			System.out.println("Checking for Captcha--");
			if (msg.contains("Please click on I'm not a robot")) {
				System.out.println("Captch displayed for login :- " + msg);
				// Thread.sleep(2000);
				driver.close();
			}

		} catch (Exception e) {

		}
		// finally
		// {System.out.println("finally block is always executed");}

		try {
			System.out.println("Checking for Error message--");
			String msg = driver.findElement(By.id("userMessage")).getText();
			// System.out.println(msg);
			if (msg.contains("Error found")) {
				System.out.println("Error occured while login attempt with message " + msg);
				// Thread.sleep(2000);
				driver.close();
			}

		} catch (Exception e) {
			System.out.println("No error message found");
		}
		try {
			System.out.println("Checking for Already login");
			WebDriverWait wait = new WebDriverWait(driver, 4);
			wait.until(ExpectedConditions.elementToBeClickable(login.yesbutton));
			driver.switchTo().activeElement();
			login.alertyes();
			log.debug("Alert found for already login");
			log.debug("Accept the alert");
			System.out.println("Alert found for already login");
			System.out.println("Accept the alert");

		} catch (Exception e) {
			// exception handling
			System.out.println("Alert not found for already login");
			log.debug("Alert not found for already login");
		}
		// login.alertyes();

		try {
			System.out.println("Checking for password Expired alert--");
			WebDriverWait wait = new WebDriverWait(driver, 1);
			wait.until(ExpectedConditions.elementToBeClickable(login.okbutton));
			driver.switchTo().activeElement();
			login.okbutton.click();
			System.out.println("Alert found for password expired");
		} catch (Exception e) {
			System.out.println("No alert found for password expired");
		}

		// log.debug("Accept the alert");

		System.out.println("Waiting for dashboard loading");
		log.debug("Waiting for dashboard loading");
		Thread.sleep(7000);
	}

}
