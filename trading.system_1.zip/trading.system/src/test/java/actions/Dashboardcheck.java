package actions;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import pages.LoginPage;
import pages.TradersDetailsPage;
import resources.TestBase;

public class Dashboardcheck extends TestBase{
	public LoginPage lp;
	WebDriver driver;
	static public Logger log = Logger.getLogger("devpinoyLogger");
	static public String log4jConfPath = "Log4j.properties";
	

	
	public Dashboardcheck(WebDriver driver) {
		this.driver=driver;
		
	}
	public void checkServerConnectionStstus() {
		log.info("*********************checkServerConnectionStstus*********************");
		TradersDetailsPage dash = PageFactory.initElements(driver, TradersDetailsPage.class);

		try {
			System.out.println("Checking server coneection status.");
			log.debug("Checking server coneection status.");
			Thread.sleep(4000);
			String color1 = dash.ServerConnectionStatus.getCssValue("color");

			String[] hexaValue = color1.replace("rgba(", "").replace(")", "").split(",");

			int hexaValue1 = Integer.parseInt(hexaValue[0]);
			hexaValue[1] = hexaValue[1].trim();
			int hexaValue2 = Integer.parseInt(hexaValue[1]);
			hexaValue[2] = hexaValue[2].trim();
			int hexaValue3 = Integer.parseInt(hexaValue[2]);

			String actualColor1 = String.format("#%02x%02x%02x", hexaValue1, hexaValue2, hexaValue3);

			Assert.assertEquals("#00cc00", actualColor1);
			System.out.println("Actual color Matched with green");
			log.debug("Actual color Matched with green");
		} catch (Exception e) {
			System.out.println("Application is not working ");
			log.debug("Application is not working ");
			driver.close();
		}
	}

	public void checkButtomPanel() throws InterruptedException {
		log.info("*********************checkButtomPanel*********************");
		TradersDetailsPage dash = PageFactory.initElements(driver, TradersDetailsPage.class);

		Thread.sleep(2000);
		dash.panneldot.click();
		Thread.sleep(5000);
		System.out.println("Click to hide the button panel");
		log.debug("Click to hide the button panel");
		dash.unhidepannel.click();
		System.out.println("Click to unhidden the button panel");
		log.debug("Click to unhidden the button panel");
		Thread.sleep(5000);
	}

	public void checkMainSetting() throws InterruptedException {
		log.info("*********************checkMainSetting*********************");
		TradersDetailsPage dash = PageFactory.initElements(driver, TradersDetailsPage.class);
		dash.checkmainsetting();
		System.out.println("Open main products list setting  ");
		Thread.sleep(2000);
		dash.selectednon.click();
		dash.savesetting();

		Thread.sleep(15000);
		System.out.println("No products groups displayed");
		log.debug("No products groups displayed");
		dash.checkmainsetting();
		System.out.println("Open main products list setting  ");
		log.debug("Open main products list setting  ");
		Thread.sleep(2000);
		dash.selecallproduct();
		System.out.println("select all products groups");
		log.debug("select all products groups");
		Thread.sleep(3000);
		dash.savesetting();
		Thread.sleep(15000);

	}

	public void checkListOfProduct() throws InterruptedException {
		log.info("*********************checkListOfProduct*********************");
		TradersDetailsPage dash = PageFactory.initElements(driver, TradersDetailsPage.class);

		dash.openlistofproduct.click();

		System.out.println("List of application get opened ");
		log.debug("List of application get opened ");
		Thread.sleep(5000);
		for (int i = 0; i < dash.allproductlist.size(); i++) {
			Thread.sleep(3000);
			System.out.println("List of product Display are:\n" + dash.allproductlist.get(i).getText());
			log.debug("List of product Display are:\n" + dash.allproductlist.get(i).getText());
		}
		dash.openlistofproduct.click();

	}

	public void checkUserProfleDetails() throws InterruptedException {
		log.info("*********************checkUserProfleDetails*********************");
		TradersDetailsPage dash = PageFactory.initElements(driver, TradersDetailsPage.class);

		dash.clickonprofile.click();
		for (int i = 0; i < dash.profilemenu.size(); i++) {
			System.out.println("Menu under profile:\n" + dash.profilemenu.get(i).getText());
			log.debug("Menu under profile:\n" + dash.profilemenu.get(i).getText());
		}
		Thread.sleep(4000);
		dash.profiledetail.click();
		System.out.println("Profile details checked");
		log.debug("Profile details checked");
		Thread.sleep(2000);
		dash.clickonprofile.click();
		Thread.sleep(2000);
		dash.homeprofile.click();
		System.out.println("Back to profile home");
		log.debug("Back to profile home");
		Thread.sleep(2000);
		//dash.clickonprofile.click();

	}

	public void checkApplicationStstus() throws InterruptedException {
		log.info("*********************checkApplicationStstus*********************");
		TradersDetailsPage dash = PageFactory.initElements(driver, TradersDetailsPage.class);

		System.out.println("Checking application status.");
		log.debug("Checking application status.");
		Thread.sleep(4000);
		String color = dash.applicationstatus.getCssValue("color");
	
		String[] hexValue = color.replace("rgba(", "").replace(")", "").split(",");

		int hexValue1 = Integer.parseInt(hexValue[0]);
		hexValue[1] = hexValue[1].trim();
		int hexValue2 = Integer.parseInt(hexValue[1]);
		hexValue[2] = hexValue[2].trim();
		int hexValue3 = Integer.parseInt(hexValue[2]);

		String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3);

		Assert.assertEquals("#00cc00", actualColor);
		System.out.println("Actual color Matched with green");
		log.debug("Actual color Matched with green");
		Thread.sleep(5000);
	}

	public void checkWithoutEmptyLiquidity() throws InterruptedException {
		log.info("*********************checkWithoutEmptyLiquidity*********************");
		TradersDetailsPage dash = PageFactory.initElements(driver, TradersDetailsPage.class);
		Thread.sleep(2000);
		dash.skipempty.click();
		System.out.println("Apply to skip Empty liquidity ");
		log.debug("Apply to skip Empty liquidity ");
		Thread.sleep(5000);

		try {
			WebDriverWait wait = new WebDriverWait(driver, 2);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class='fa fa-caret-down']")));
			WebElement caretdown = driver.findElement(By.xpath("//span[@class='fa fa-caret-down']"));
			caretdown.click();
			System.out.println("caret get collaps");
			log.debug("caret get collaps");
		} catch (Exception e) {
			System.out.println("caret already collaps");
			log.debug("caret already collaps");
		}
		Thread.sleep(5000);
		for (int i = 0; i < dash.leftsideproduct.size(); i++) {
			Thread.sleep(3000);
			System.out.println("List of left side products without empty liquidity are:\n"
					+ dash.leftsideproduct.get(i).getText());
			log.debug("List of left side products without empty liquidity are:\n"
					+ dash.leftsideproduct.get(i).getText());
		}
		Thread.sleep(5000);
		for (int i = 0; i < dash.righsidelist.size(); i++) {
			Thread.sleep(3000);
			System.out.println(
					"List of right side products without empty liquidity are:\n" + dash.righsidelist.get(i).getText());
			log.debug(
					"List of right side products without empty liquidity are:\n" + dash.righsidelist.get(i).getText());
		}
	}

	public void checkWithEmptyLiquidity() throws InterruptedException {
		log.info("*********************checkWithEmptyLiquidity*********************");
		TradersDetailsPage dash = PageFactory.initElements(driver, TradersDetailsPage.class);
		
		dash.skipempty.click();
		Thread.sleep(2000);
		System.out.println("Allowed skip liquidity ");
		log.debug("Allowed skip liquidity ");
		Thread.sleep(5000);
		for (int i = 0; i < dash.leftsideproduct.size(); i++) {
			System.out.println("List of products with empty liquidity are:\n" + dash.leftsideproduct.get(i).getText());
			log.debug("List of products with empty liquidity are:\n" + dash.leftsideproduct.get(i).getText());
		}
		for (int i = 0; i < dash.righsidelist.size(); i++) {
			System.out.println(
					"List of right side products with empty liquidity are:\n" + dash.righsidelist.get(i).getText());
			log.debug("List of right side products with empty liquidity are:\n" + dash.righsidelist.get(i).getText());
		}
	}

	public void checkThreeDot() throws InterruptedException {
		log.info("*********************checkThreeDot*********************");
		TradersDetailsPage dash = PageFactory.initElements(driver, TradersDetailsPage.class);
		dash.threedot.click();
		System.out.println("More option open");
		log.debug("More option open");
		// dash.threedot.click();
		Thread.sleep(2000);
		dash.helpdot.click();
		System.out.println("Help menu open");
		log.debug("Help menu open");
		Thread.sleep(2000);
		dash.closehelpdot.click();
		System.out.println("Help menu closed");
		log.debug("Help menu closed");
		Thread.sleep(2000);
		dash.threedot.click();
		dash.hotdot.click();
		System.out.println("Hot menu open");
		log.debug("Hot menu open");
		Thread.sleep(2000);

		dash.closehotdot.click();
		System.out.println("Hot menu closed");
		log.debug("Hot menu closed");
		Thread.sleep(2000);
		dash.threedot.click();
		Thread.sleep(2000);
		dash.savedot.click();
		System.out.println("Clicked on saved");
		log.debug("Clicked on saved");
		System.out.println("Toast mesage are :- " + dash.toastmsg.getText());
	}

	public void userClickCountCheck() throws InterruptedException {
		TradersDetailsPage dash = PageFactory.initElements(driver, TradersDetailsPage.class);
		Thread.sleep(2000);
		dash.userclickcount.click();
		System.out.println("Open user click count panel");
		log.debug("Open user click count panel");
		Thread.sleep(5000);

		for (int i = 0; i < dash.currencylist.size(); i++) {
			System.out.println("List of currency in user click count are:\n" + dash.currencylist.get(i).getText());
			log.debug("List of currency in user click count are:\n" + dash.currencylist.get(i).getText());
		}
		Thread.sleep(2000);
		dash.userclickcountclosed.click();
		System.out.println("Closed user click count panel ");
		log.debug("Closed user click count panel ");
	}

	public void quickOrderCheck() throws InterruptedException {
		TradersDetailsPage dash = PageFactory.initElements(driver, TradersDetailsPage.class);
		Thread.sleep(2000);
		dash.plusbutton.click();
		System.out.println("Click on plus button to add trade");
		dash.rateentry.sendKeys(Keys.ESCAPE);

		Thread.sleep(2000);

		System.out.println("Entry popup get closed ");
	}

}
