package actions;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import pages.LoginPage;
import resources.TestBase;

public class Logout extends TestBase{
	WebDriver driver ;
	static public Logger log = Logger.getLogger("devpinoyLogger");
	static public String log4jConfPath = "Log4j.properties";
	
	public Logout(WebDriver driver) {
		this.driver=driver;
	}
	public void logout() throws InterruptedException {
		LoginPage login = PageFactory.initElements(driver, LoginPage.class);
		
		
		login.openprofile();
		log.debug("profile open");
		Thread.sleep(2000);
		login.logout();
		System.out.println("Trader loged out successful");
		log.debug("log out successful");
	}

}
