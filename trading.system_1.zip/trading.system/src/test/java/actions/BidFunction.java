package actions;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import pages.TradingBIDpage;
import resources.TestBase;

public class BidFunction extends TestBase {
	WebDriver driver;

	public BidFunction(WebDriver driver) {
		this.driver = driver;
	}

	public void checkCaretExpand() throws InterruptedException {
		TradingBIDpage tb = PageFactory.initElements(driver, TradingBIDpage.class);
		Thread.sleep(2000);
		try {
			WebDriverWait wait = new WebDriverWait(driver, 2);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(
					"//div[@id='productWrapper']/div[1]/div[1]/table/thead/tr/th[1]/div/div/a/span[@class='fa fa-caret-right']")));

			tb.caretright.click();
			System.out.println("Caret expand");
		} catch (Exception e) {
			System.out.println("Caret Already expand");
		}
	}

	public void listOfProduct() throws InterruptedException {
		TradingBIDpage tb = PageFactory.initElements(driver, TradingBIDpage.class);

		System.out.println("List of pits Display are:\n ");
		log.debug("List of pits Display are:\n ");

		for (int j = 0; j < tb.pitlist.size(); j++) {
			Thread.sleep(2000);
			System.out.println(tb.pitlist.get(j).getText());
			log.debug(tb.pitlist.get(j).getText());

		}
	}

	public void listOfPit() throws InterruptedException {
		TradingBIDpage tb = PageFactory.initElements(driver, TradingBIDpage.class);
		Thread.sleep(3000);

		tb.firstpitbid.click();
		System.out.println("click for bid");
		log.debug("click for bid");
		Thread.sleep(3000);
		tb.priceset.sendKeys(Keys.SHIFT, Keys.ARROW_UP);

	}

	public void createBidOnProduct() throws InterruptedException {
		TradingBIDpage tb = PageFactory.initElements(driver, TradingBIDpage.class);
		String Pname = tb.productname.getText();
		Thread.sleep(3000);

		if (tb.bidsubmit.isDisplayed()) {
			tb.bidsubmit.click();
			Thread.sleep(3000);
		} else {
			tb.modifybid.click();
		}

		try {
			WebDriverWait wait = new WebDriverWait(driver, 2);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.accept();
			System.out.println("Alert accepted ");
			log.debug("Alert accepted ");
		} catch (Exception e) {
			System.out.println("No alert displayed");
			log.debug("No alert displayed");
		}

		tb.OblotterProduct.click();
		System.out.println("You make Bid on :" + Pname);
		log.debug("You make Bid on :" + Pname);
	}

	public void checkBlotterAndStroke() throws InterruptedException {
		TradingBIDpage tb = PageFactory.initElements(driver, TradingBIDpage.class);
		String Pname = tb.productname.getText();
		Thread.sleep(3000);

		String OBname = tb.OblotterProduct.getText();
		Thread.sleep(3000);
		String OBrate = tb.OblotterRate.getText();

		System.out.println("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		log.debug("Product name displayed in order Blotter is " + OBname + " with rate  " + OBrate);
		if (Pname.equals(OBname)) {
			System.out.println("Product name are displayed on order blotter are same ");
			log.debug("Product name are displayed on order blotter are same ");
		} else {
			System.out.println("Product name are displayed on order blotter are not same ");
			log.debug("Product name are displayed on order blotter are not same ");
		}

		tb.ksbutton.click();
		Thread.sleep(2000);
		String KSAction = tb.KeyStrokeAction.getText();
		String KSStatus = tb.KeyStrokeStatus.getText();

		System.out.println("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
		log.debug("Action displayed in Key stroke is " + KSAction + " with status  " + KSStatus);
	}

}
